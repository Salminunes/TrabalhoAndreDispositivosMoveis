package com.example.trabalhosalmi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ItemEdicao extends AppCompatActivity {

    private EditText edtNome;
    private EditText edtFone;
    private FloatingActionButton btnEditar, btnExcluir;

    ItemRepositorio itemRepositorio;

    private SQLiteDatabase conexao;
    private DadosOpenHelper dadosOpenHelper;

    Item item = new Item();

    int codigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edtNome = findViewById(R.id.nome);
        edtFone = findViewById(R.id.telefone);

        btnEditar = findViewById(R.id.btnEditar);
        btnExcluir = findViewById(R.id.btnExcluir);

        Bundle bundle = getIntent().getExtras();

        if( bundle!= null && bundle.containsKey("DADOS")){

            item = (Item)bundle.getSerializable("DADOS");

            codigo = item.getCodigo();

            edtNome.setText(item.getNome());
            edtFone.setText(item.getFone());

        }

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                criarConexao();

                item.setCodigo(codigo);
                item.setNome(edtNome.getText().toString());
                item.setFone(edtFone.getText().toString());

                itemRepositorio.alterar(item);

                Toast.makeText(getApplicationContext(), "Alteração efetuada com sucesso!", Toast.LENGTH_SHORT).show();

                Intent it = new Intent(ItemEdicao.this, MainActivity.class);
                startActivity(it);

            }
        });

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                new AlertDialog.Builder(view.getContext())
                        .setTitle("Excluir")
                        .setMessage("Deseja excluir?")
                        .setPositiveButton("sim", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int opcao) {
                                criarConexao();
                                itemRepositorio.excluir(codigo);

                                Toast.makeText(getApplicationContext(), "Exclusão efetuada com sucesso!", Toast.LENGTH_SHORT).show();

                                Intent it = new Intent(ItemEdicao.this, MainActivity.class);
                                startActivity(it);
                            }
                        })
                        .setNegativeButton("nao", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int opcao) {

                                dialog.dismiss();

                            }
                        }).show();


            }
        });
    }


    private void criarConexao() {

        try {
            dadosOpenHelper = new DadosOpenHelper(this);
            conexao = dadosOpenHelper.getWritableDatabase();
            itemRepositorio = new ItemRepositorio(conexao);
        } catch (SQLException e) {
            Toast.makeText(getApplicationContext(), "Problema ao conectar!", Toast.LENGTH_SHORT).show();
        }


    }


}

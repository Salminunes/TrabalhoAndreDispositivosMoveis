package com.example.trabalhosalmi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Item> listaDados;
    RecyclerView recycle;
    private FloatingActionButton btnSalvar;

    private SQLiteDatabase conexao;
    private DadosOpenHelper dadosOpenHelper;
    private Item item;

    private EditText edtNome;
    private EditText edtFone;

    ItemRepositorio itemRepositorio;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycle = findViewById(R.id.recyclerView);
        recycle.setLayoutManager(new LinearLayoutManager(this, LinearLayout.VERTICAL,false));


        listaDados = new ArrayList<Item>();

        criarConexao();

        listaDados = itemRepositorio.buscarTodos();

        if(listaDados != null) {
            AdapterDados adapter = new AdapterDados(listaDados);
            recycle.setAdapter(adapter);
        }

        btnSalvar = findViewById(R.id.btnSalvar);
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNome = findViewById(R.id.nome);
                edtFone = findViewById(R.id.telefone);

                criarConexao();

                item = new Item();
                item.setNome(edtNome.getText().toString());
                item.setFone(edtFone.getText().toString());

                itemRepositorio.inserir(item);

                Toast.makeText(getApplicationContext(), "Inclusão efetuada com sucesso!", Toast.LENGTH_SHORT).show();

                finish();

                Intent it = new Intent(MainActivity.this, MainActivity.class);
                startActivity(it);
            }
        });

    }

    private void criarConexao() {

        try {
            dadosOpenHelper = new DadosOpenHelper(this);
            conexao = dadosOpenHelper.getWritableDatabase();
            itemRepositorio = new ItemRepositorio(conexao);
        } catch (SQLException e) {
            Toast.makeText(getApplicationContext(), "Problema ao conectar!", Toast.LENGTH_SHORT).show();
        }


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
